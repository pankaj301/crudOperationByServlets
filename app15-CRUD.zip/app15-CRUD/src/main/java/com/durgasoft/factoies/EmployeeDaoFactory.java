package com.durgasoft.factoies;

import com.durgasot.dao.EmployeeDao;
import com.durgasot.dao.EmployeeDaoImple;
public class EmployeeDaoFactory 
{
	private static EmployeeDao employeeDao=null;
	static {
		employeeDao=new EmployeeDaoImple(); 
				}
	public static EmployeeDao getEmployeeDao()
	{
			return employeeDao;
	}
}
