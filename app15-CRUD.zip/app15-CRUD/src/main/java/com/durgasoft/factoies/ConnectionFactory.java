package com.durgasoft.factoies;

import java.sql.Connection;
import java.sql.DriverManager;

import jakarta.servlet.jsp.tagext.TryCatchFinally;

public class ConnectionFactory 
{
	private static Connection connection=null;
	static 
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/durgadb","root","pooja");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
	}
	public static Connection getConnection() {
		return connection;
	}
	public static void close() {
		try {			
			connection.close();
			System.out.println("Connection closing......");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
