package com.durgasoft.factoies;

import com.durgasoft.service.EmployeeService;
import com.durgasoft.service.EmployeeServiceImple;

public class EmployeeServiceFactory 
{
	private static EmployeeService employeeService=null;
	static
	{
		employeeService=new EmployeeServiceImple();
	}
	public static EmployeeService getEmployeeService() {
		return employeeService;
	}
}
